<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Items CRUD</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('itemCRUD.create')); ?>"> Create New Item</a>
            </div>
        </div>
    </div>

    <?php if($message=Session::get('success')): ?>
    <div class="alert alert-success">
        <?php echo e($message); ?>    
    </div>        
    <?php endif; ?>
    
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Description</th>
            <th width="280px">Action</th>
        </tr>
        
        <?php foreach($items as $item): ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($item->item); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td>
                    
                    <a class="btn btn-info" href="<?php echo e(route('itemCRUD.show',$item->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('itemCRUD.edit',$item->id)); ?>">Edit</a>
                    <form method='post' action='<?php echo e(route('itemCRUD.destroy',$item->id)); ?>' >
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('delete')); ?>

                    
                        <button type="submit" class="btn btn-primary">
                        Delete</button>  
                    </form>
                
                
                </td>    
            </tr>
        <?php endforeach; ?>
    </table>
    <?php echo $items->render(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>